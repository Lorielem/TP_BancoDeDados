package pkgLocadora;

/**
 *
 * 
 */
public class Filme extends Midia{

    public Filme() {
    }

    public Filme(String titulo, String classificacao, String categoria, int duracao, double real, Data lancamento) {
        super(titulo, classificacao, categoria, duracao, real, lancamento);
    }

}
