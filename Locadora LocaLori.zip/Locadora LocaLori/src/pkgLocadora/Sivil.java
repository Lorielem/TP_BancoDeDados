package pkgLocadora;

import java.util.ArrayList;

/**
 *
 * 
 */
public class Sivil {

    private ArrayList<Cliente> clientes = new ArrayList<>();
    private ArrayList<Midia> midias = new ArrayList<>();
    private ArrayList<Locacao> locacoes = new ArrayList();
    private ArrayList<Midia> midiasLocadas = new ArrayList<>();
    private Funcionario operador = new Funcionario();
    private double lucro;
    
    public Sivil(){
    
    }
    
    public boolean cadastrarPessoa(Cliente p) {
        for (Pessoa i : clientes) {
            if (i.getCpf().equals(p.getCpf())) {
                return false;
            }
        }
        clientes.add(p);
        return true;
    }

    public boolean removerPessoa(String cpf){
        for(Pessoa i : clientes){
            if(i.getCpf().equals(cpf)){
                clientes.remove(i);
                return true;
            }
        }
        return false;
    }
    
    public boolean cadastrarMidia(Midia nova){
        midias.add(nova);
        return true;
    }

    public boolean removerMidia(int issn){
        for (Midia i : midias){
            if(i.getIssn() == issn){
                midias.remove(i);
            return true;
            }
        }
        return false;
    }
    public String buscaPessoa(String cpf){
        for (int i = 0; i < clientes.size(); i++) {
            if(clientes.get(i).getCpf().equals(cpf)){
                return clientes.get(i).toString();
            }
        }
        return "Pessoa não encontrada!";
    }
    
    public String buscaMidia(String titulo){
        
        for(int i=0; i< midias.size(); i++){
            if(titulo.equals(midias.get(i).getTitulo())){
                return midias.get(i).imprimeMidia();
            }
        }
    return "Midia não encontrada";
    }
    
    public String buscaMidiaIssn(int issn){
        
        for(int i=0; i< midias.size(); i++){
            if(issn == midias.get(i).getIssn()){
                return midias.get(i).imprimeMidia();
            }
        }
    return "Midia não encontrada";
    }
    
    public String concatenaMidias(){
        String str = "";
        for(Midia a : midias){
            str += a.imprimeLista();
        }

        return str;
    }    
    
    public String concatenaPessoas(){
        String str = "";
        for(Pessoa a : clientes){
            str += a.imprimeLista();
        }
        
        return str;
    }    
    
    public String AlugarMidia (int issn, String cpf){
        boolean midiaBuscada = false;
        boolean pessoaBuscada = false;
        int iMidia = 0, iPessoa = 0;
        double preco = 0.0;
        
        for(int i=0; i< midias.size(); i++){
            if(issn == midias.get(i).getIssn()){
               if(midias.get(i).isLocado()){
                   return "Midia já Locada!";
               }
               else{
               midiaBuscada = true;
               iMidia = i;
               break;
               }
            }    
        }
        if(midiaBuscada == false){
            return "Midia não encontrada!";
        }
        else{
            for (int i = 0; i < clientes.size(); i++) {
                if(clientes.get(i).getCpf().equals(cpf)){
                    pessoaBuscada = true;
                    iPessoa = i;
                    break;
                }
            }
            if(pessoaBuscada == false){
                return "Pessoa não encontrada!";
            }
            else{
                    
                clientes.get(iPessoa).getMidiasCliente().add(midias.get(iMidia));
                midias.get(iMidia).setLocado(true);
                
                preco = midias.get(iMidia).getReal() - clientes.get(iPessoa).getDesconto();

                clientes.get(iPessoa).setSaldoModificado(preco);
                lucro += preco;
                Locacao nova = new Locacao(operador, clientes.get(iPessoa), midias.get(iMidia));
                locacoes.add(nova);
                
                return "Locação Efetivada!";
            }
        }
    }
    
    public String devolverMidia(int issn, String cpf){
        double preco = 0.0;
        for (int iP = 0; iP < clientes.size(); iP++) {
            if(clientes.get(iP).getCpf().equals(cpf)){
                
                for (int iM=0 ; iM < clientes.get(iP).getMidiasCliente().size() ; iM++) {
                    if(issn == clientes.get(iP).getMidiasCliente().get(iM).getIssn()){
                        
                        preco = clientes.get(iP).getMidiasCliente().get(iM).getReal() - clientes.get(iP).getDesconto();
                        clientes.get(iP).setSaldoModificado(-preco);

                        clientes.get(iP).getMidiasCliente().remove(iM);
                        for(int i=0; i< midias.size(); i++){
                            if(issn == midias.get(i).getIssn()){
                                midias.get(i).setLocado(false);
                                for (int j = 0; j < locacoes.size(); j++) {
                                    if(issn == locacoes.get(j).getMidiaLocada().getIssn()){
                                        locacoes.remove(j);
                                        break;
                                    }
                                }
                                return "Devolução Concluída!";
                            }
                        }
                    }
                }
            }
        }
        return "Erro na Devolução! Verifique as informações";
    }
        
    public String listaMidiaAlocada(){
        int issn;
        String str = "Midias: " + midias.size()+
                     "\nMidias locadas: " + locacoes.size()+
                     "\nLucro: R$" + lucro;
        for(int i=0; i< locacoes.size(); i++){
            str += "\n\nLocações: \nTitulo: " + locacoes.get(i).getMidiaLocada().getTitulo() +
                   "\nIssn: " + locacoes.get(i).getMidiaLocada().getIssn()+
                   "\nLocado por: " + locacoes.get(i).getCliente().getNome() +
                   "\nOperador: " + locacoes.get(i).getOperador().getNome();
        }
        return str;
    }
    
    public void imprimeArrayMidias(){
        for(Midia a : midias){
            System.out.println(a.imprimeMidia());
        }
        
    }
    
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public ArrayList<Midia> getMidias() {
        return midias;
    }

    public void setMidias(ArrayList<Midia> midias) {
        this.midias = midias;
    }

    public Funcionario getOperador() {
        return operador;
    }

    public void setOperador(Funcionario operador) {
        this.operador = operador;
    }
    
    
}
