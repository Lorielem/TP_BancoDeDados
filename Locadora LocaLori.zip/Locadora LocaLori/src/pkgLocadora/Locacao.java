package pkgLocadora;

/**
 *
 * 
 */
public class Locacao {
    private Funcionario operador;
    private Cliente cliente;
    private Midia midiaLocada;

    public Locacao() {
    }

    public Locacao(Funcionario operador, Cliente cliente, Midia midiaLocada) {
        this.operador = operador;
        this.cliente = cliente;
        this.midiaLocada = midiaLocada;
    }
    

    public Funcionario getOperador() {
        return operador;
    }

    public void setOperador(Funcionario operador) {
        this.operador = operador;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Midia getMidiaLocada() {
        return midiaLocada;
    }

    public void setMidiaLocada(Midia midiaLocada) {
        this.midiaLocada = midiaLocada;
    }
    
}
