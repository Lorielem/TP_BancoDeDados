package pkgLocadora;

import java.util.ArrayList;

/**
 *
 * 
 */
abstract class Midia {
   
    protected static int counter = 0;
    protected int issn = 0;
    protected String titulo, classificacao, categoria;
    protected int duracao, quantidade;
    protected double real;
    protected boolean locado;
    protected Data lancamento;
    protected Data dataLocacao;
    protected Data dataDevolucao;
    
    public Midia() {
    }

    public Midia(String titulo) {
        this.titulo = titulo;
    }

    public Midia(String titulo, int duracao) {
        this.titulo = titulo;
        this.duracao = duracao;
    }
    
    public Midia(String titulo, String classificacao, String categoria, int duracao, double real, Data lancamento) {
        this.titulo = titulo;
        this.classificacao = classificacao;
        this.categoria = categoria;
        this.duracao = duracao;
        this.real = real;
        this.lancamento = lancamento;
        quantidade++;
        issn = ++counter;
    }
     
    public String concatenaMidiasCliente(ArrayList<Midia> midias){
        String str = "";
        for(Midia a : midias){
            str += a.imprimeLista();
        }
        
        return str;
    }    
    
    public String imprimeLista(){
        return "Título: " + titulo + "  Issn: "+ issn + "\n";
    }
    public String imprimeMidia(){
        String simNao;
        if(locado){ simNao = "Sim";} else { simNao = "Não";}
        return "Midia\n" + "titulo = " + titulo + 
                "\nclassificacao = " + classificacao + 
                "\ncategoria = " + categoria + 
                "\nissn = " + issn + 
                "\nduracao = " + duracao + 
                "\nquantidade = " + quantidade + 
                "\npreco = R$ " + real + 
                "\nlocado = " + simNao + 
                "\nlancamento = " + lancamento.toString()+ "\n"; 
    }
    
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getIssn() {
        return issn;
    }

    public void setIssn(int issn) {
        this.issn = issn;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getReal() {
        return real;
    }

    public void setReal(double real) {
        this.real = real;
    }

    public boolean isLocado() {
        return locado;
    }

    public void setLocado(boolean locado) {
        this.locado = locado;
    }

    public Data getLancamento() {
        return lancamento;
    }

    public void setLancamento(Data lancamento) {
        this.lancamento = lancamento;
    }

}
