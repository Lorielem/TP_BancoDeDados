package pkgLocadora;

/**
 *
 * 
 */
public class Serie extends Midia{
    private int temporada;
    private String episodio;
    private int qtdSerie;
    
    public Serie() {
    }

    public Serie(int temporada, String episodio, String titulo, String classificacao, String categoria, int duracao, double real, Data lancamento) {
        super(titulo, classificacao, categoria, duracao, real, lancamento);
        this.temporada = temporada;
        this.episodio = episodio;
        ++qtdSerie;
    }
    
    @Override
    public String imprimeMidia() {
        return super.imprimeMidia() + "Temporada: " + temporada + "\nEpisodio: " + episodio;
    }
    
    public int getTemporada() {
        return temporada;
    }

    public void setTemporada(int temporada) {
        this.temporada = temporada;
    }

    public String getEpisodio() {
        return episodio;
    }

    public void setEpisodio(String episodio) {
        this.episodio = episodio;
    }
    
}
