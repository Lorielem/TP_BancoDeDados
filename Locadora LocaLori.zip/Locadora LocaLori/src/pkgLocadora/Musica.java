package pkgLocadora;

/**
 *
 * 
 */
public class Musica extends Midia{
    private String cantor;
    private int qtdMusicas;

    public Musica() {
    }

    public Musica(String cantor, String titulo, String classificacao, String categoria, int duracao, double real, Data lancamento) {
        super(titulo, classificacao, categoria, duracao, real, lancamento);
        this.cantor = cantor;
        ++qtdMusicas;
    }
    
    @Override
    public String imprimeMidia() {
        return super.imprimeMidia() + "Cantor: " + cantor; 
    }
        
    public String getCantor() {
        return cantor;
    }

    public void setCantor(String cantor) {
        this.cantor = cantor;
    }

    public int getQtdMusicas() {
        return qtdMusicas;
    }

    public void setQtdMusicas(int qtdMusicas) {
        this.qtdMusicas = qtdMusicas;
    }

}
