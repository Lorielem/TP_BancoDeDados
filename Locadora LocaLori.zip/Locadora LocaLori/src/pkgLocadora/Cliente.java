package pkgLocadora;

import java.util.ArrayList;
/**
 *
 * 
 */
public class Cliente extends Pessoa{
    private Double saldo = 0.0, desconto = 0.0;
    private ArrayList<Midia> midiasCliente;

    public Cliente(){
        
    }

    public Cliente(String nome, String cpf, String telefone, String sexo, Endereco endereco, Data dataNascimento, Data dataCadastro) {
        super(nome, cpf, telefone, sexo, endereco, dataNascimento, dataCadastro);
        midiasCliente = new ArrayList<>();
    }

    @Override
    public String toString() {
        return super.toString() + "\nsaldo = " + saldo + "\n\nMidias Cliente:\n" + concatenaMidiasCliente(midiasCliente);
    }
    
    public String concatenaMidiasCliente(ArrayList<Midia> midias){
        String str = "";
        for(Midia a : midias){
            str += a.imprimeLista();
        }
        
        return str;
    }    

    public ArrayList<Midia> getMidiasCliente() {
        return midiasCliente;
    }

    public void setMidiasCliente(ArrayList<Midia> midiasCliente) {
        this.midiasCliente = midiasCliente;
    }
    
    public Double getDesconto() {
        return desconto;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }
    
    public Double getSaldo() {
        return saldo;
    }

    public void setSaldoModificado(Double valor) {
        this.saldo = saldo - valor;
    }
    
}
