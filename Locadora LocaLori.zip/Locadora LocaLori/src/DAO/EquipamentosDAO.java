package DAO;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import pkgLocadora.Filme;

/**
 *
 * @author Lorielem
 */
public class EquipamentosDAO {
    
     public void create(Filme e){
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO produto (codigo, tipo, conservacao, classe)VALUES(?,?,?, ?)");
            stmt.setInt(1, e.getDuracao());
            stmt.setString(2, e.getTitulo());
            stmt.setString(3, e.getCategoria());
            stmt.setString(4, e.getCategoria());
            
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public List<Filme> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Filme> produtos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM produto");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Filme produto = new Filme();

                produto.setDuracao(rs.getInt("Codigo"));
                produto.setTitulo(rs.getString("Descricao"));
                produto.setClassificacao(rs.getString("Conservacao"));
                produto.setCategoria(rs.getString("Classe"));
               
                produtos.add(produto);
            }

        } catch (SQLException ex) {
            Logger.getLogger(EquipamentosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return produtos;

    }
    
    public List<Filme> readForDesc(String desc) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Filme> produtos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM produto WHERE descricao LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Filme produto = new Filme();

                produto.setDuracao(rs.getInt("Codigo"));
                produto.setTitulo(rs.getString("Descricao"));
                produto.setClassificacao(rs.getString("Conservacao"));
                produto.setCategoria(rs.getString("Classe"));
               
                produtos.add(produto);
                               
            }

        } catch (SQLException ex) {
            Logger.getLogger(EquipamentosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return produtos;

    }

    public void update(Filme e) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            
            stmt = con.prepareStatement("INSERT INTO produto (codigo, tipo, conservacao, classe)VALUES(?,?,?, ?)");
            stmt.setInt(1, e.getDuracao());
            stmt.setString(2, e.getTitulo());
            stmt.setString(3, e.getCategoria());
            stmt.setString(4, e.getCategoria());
            
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    public void delete(Filme p) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM produto WHERE codigo = ?");
            stmt.setInt(1, p.getDuracao());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    }

   
