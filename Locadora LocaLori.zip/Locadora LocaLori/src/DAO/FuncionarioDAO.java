package DAO;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import pkgLocadora.Funcionario;
/**
 *
 * @author Lorielem
 */
public class FuncionarioDAO {
    public void create(Funcionario f){
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO produto (nome, cpf, telefone, sexo, cargo, salario) VALUES(?,?,?, ?)");
            stmt.setString(1, f.getNome());
            stmt.setString(2, f.getCpf());
            stmt.setString(3, f.getTelefone());
            stmt.setString(4, f.getSexo());    
            stmt.setString(5, f.getCargo());
            stmt.setDouble(6, f.getSalario());
                 
                          
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public List<Funcionario> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Funcionario> produtos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM produto");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Funcionario func = new Funcionario();

                func.setNome(rs.getString("Nome"));
                func.setCpf(rs.getString("CPF"));                
                func.setTelefone(rs.getString("Telefone"));
                func.setSexo(rs.getString("Sexo"));
                func.setCargo(rs.getString("cargo"));
                func.setSalario(rs.getDouble("Salario"));
               
                produtos.add(func);
            }

        } catch (SQLException ex) {
            Logger.getLogger(EquipamentosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return produtos;

    }
    
    public List<Funcionario> readForDesc(String desc) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Funcionario> clientes = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM produto WHERE descricao LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Funcionario f = new Funcionario();                         
                
                
            f.setCpf(rs.getString("Cpf"));
            f.setNome(rs.getString("Nome"));
            f.setTelefone(rs.getString("Telefone"));
            f.setSexo(rs.getString("Sexo"));
            f.setCargo(rs.getString("cargo"));
            f.setSalario(rs.getDouble("Salario"));
            
                                              
            clientes.add(f);
                               
            }

        } catch (SQLException ex) {
            Logger.getLogger(FuncionarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return clientes;

    }

    public void update(Funcionario f) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            
            stmt = con.prepareStatement("INSERT INTO produto (nome, cpf, telefone, sexo, cargo, salario) VALUES(?,?,?, ?)");
            stmt.setString(1, f.getNome());
            stmt.setString(2, f.getCpf());
            stmt.setString(3, f.getTelefone());
            stmt.setString(4, f.getSexo());    
            stmt.setString(5, f.getCargo());
            stmt.setDouble(6, f.getSalario());
            
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    public void delete(Funcionario f) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM produto WHERE CPF = ?");
            stmt.setString(1, f.getCpf());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
}
